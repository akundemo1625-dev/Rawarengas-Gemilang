# Website Administrasi Desa

Website ini adalah template sederhana untuk administrasi desa yang dapat diakses masyarakat.  
Bisa di-deploy ke **GitHub Pages** atau **Netlify**.

## 📌 Cara Deploy di GitHub Pages
1. Buat repository baru di GitHub
2. Upload semua file dari folder ini
3. Masuk ke Settings > Pages > pilih branch `main` dan root folder
4. Website akan bisa diakses melalui `https://username.github.io/nama-repo/`

## 🔑 Login Admin
Password default: `desa123`  
(Sebaiknya ganti password di file `assets/script.js`)

---
© 2025 Website Administrasi Desa
