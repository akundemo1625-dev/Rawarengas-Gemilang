function adminLogin() {
  const password = prompt("Masukkan password admin:");
  if (password === "desa123") {
    alert("Login berhasil! Silakan edit data di script.js sesuai kebutuhan desa Anda.");
  } else {
    alert("Password salah!");
  }
}
